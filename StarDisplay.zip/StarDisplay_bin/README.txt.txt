Star Display is a program to display acquired stars in casual playthrough! 
App reads game memory and depending on it displays Stars, Keys and Caps automatically.
The level you are at is highlighted with yellow rectangle.
Reds, Secrets, Panels are displayed on a lower bar.

If you want to get all layouts and not have them downloaded on demand, follow https://github.com/StarDisplayLayouts/layouts/archive/master.zip and unzip it. 
Move all files from folder "layouts-manager" to folder "layout" where StarDisplay.exe is.

For single missing layout, go to https://github.com/StarDisplayLayouts/layouts and get needed layout from there